<!-- views/partials/header.php -->
<header style="background: #0a3d91; color: white; padding: 12px 0; text-align: center; position: sticky; top: 0; z-index: 100;">
  <div style="max-width: 1000px; margin: auto; display: flex; align-items: center; justify-content: space-between; padding: 0 20px;">
    <div style="display: flex; align-items: center; gap: 10px;">
    <a href="http://itro.dungtt.id.vn">
      <img src="portal/itro-logo-vuong.png" alt="iTrọ Logo" width="40" style="border-radius: 8px;">
    </a>
      <div style="text-align: left;">
        <div style="font-weight: bold; font-size: 18px;">NHÀ TRỌ CHÚ QUẢNG</div>
        <div style="font-size: 13px;">Đội 6, thôn Minh Thành, Lai Khê, TP Hải Phòng</div>
      </div>
    </div>

    <a href="http://itro.dungtt.id.vn/admin" 
       style="background: white; color: #0a3d91; padding: 8px 16px; border-radius: 8px; font-weight: 600; text-decoration: none; transition: 0.2s;">
      Đăng nhập Admin
    </a>
  </div>
</header>
