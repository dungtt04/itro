<!-- views/partials/footer.php -->
<footer style="background: #f5f5f5; text-align: center; padding: 20px 10px; margin-top: 40px; font-size: 0.9em; color: #666;">
  © 2025 - Hệ thống quản lý trọ <b>iTrọ</b> | Liên hệ: 0352.153.772
</footer>
