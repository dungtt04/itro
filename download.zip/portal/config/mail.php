<?php
// config/mail.php
// Cấu hình gửi mail SMTP
return [
    'host' => 'smtp.gmail.com',
    'username' => 'tiendung2004lv@gmail.com', // Thay bằng email gửi
    'password' => 'esyu jnox evpc wpup',    // Thay bằng app password Gmail
    'port' => 587,
    'encryption' => 'tls',
    'from' => 'tiendung2004lv@gmail.com',     // Thay bằng email gửi
    'from_name' => 'Hệ thống báo cáo sự cố',
];
