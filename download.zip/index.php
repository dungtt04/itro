<?php
// index.php - Router đơn giản
ini_set('display_errors', 1);
ini_set('display_startup_errors', 1);
error_reporting(E_ALL);
$action = $_GET['action'] ?? '';
switch ($action) {
    case 'customer_create':
        require_once __DIR__ . '/portal/controllers/CustomerController.php';
        $controller = new CustomerController();
        $controller->create();
        break;
    case 'history_search':
        require_once __DIR__ . '/portal/controllers/NhatroHistoryController.php';
        $controller = new NhatroHistoryController();
        $controller->search();
        break;
    case 'history_detail':
        require_once __DIR__ . '/portal//controllers/NhatroHistoryController.php';
        $controller = new NhatroHistoryController();
        $controller->detail();
        break;
    case 'report':
        require_once __DIR__ . '/portal/controllers/ReportController.php';
        $controller = new ReportController();
        $controller->create();
        break;
    default:
        include __DIR__ . '/portal/views/home.php';
        break;
}
